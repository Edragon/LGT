/*****************************************************************************
 **	  						The C file for LGT8F88A Microprocessors  			        **
 **																	    		**
 **   						      Copyright(C) 2013, Green Tec.						**
 **  								 All rights reserved.								**
 ******************************************************************************
 **	  filename		: rf_drv.c												**
 **     version 		: v1.0														**
 **     created by 	: sean														** 
 **	  date		: 2013-09-3													**
 **	  used for mg8f88a															**
******************************************************************************/
#include "spi_drv.h"
#include "base.h"
#include "rf_drv.h"


u8 RFTX_ADDRESS[RFTX_ADR_SIZE] = {0x34,0x43,0x10,0x10,0x01};		//tx mode address
u8 RFRX_ADDRESS[RFRX_ADR_SIZE] = {0x34,0x43,0x10,0x10,0x02};		//rx mode address



#define DrvRF_24L01_FLUSH_TX()		SPSS_LOW();SPI_RDWRByte(RFCMD_FLUSH_TX);SPSS_HIGH()
#define DrvRF_24L01_FLUSH_RX()		SPSS_LOW();SPI_RDWRByte(RFCMD_FLUSH_RX);SPSS_HIGH()
#define DrvRF_24L01_REUSE_TX()		SPSS_LOW();SPI_RDWRByte(RFCMD_REUSE_TX_PL);SPSS_HIGH()
#define DrvRF_24L01_NOP()			SPSS_LOW();SPI_RDWRByte(RFCMD_NOP);SPSS_HIGH()

/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void DrvRF_24L01_WriteReg(u8 reg, u8 len,u8 *databuf)
�������ܣ�write 24L01 register
���������reg: register address
			   regdata:write data 
���ز�������
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
u8 DrvRF_24L01_WriteRegByte(u8 reg, u8 regdata)
{	
	u8 status;

	SPSS_LOW();
	status =  SPI_RDWRByte(RFCMD_W_REG | reg);
	SPI_RDWRByte(regdata);
	SPSS_HIGH();
	return (status);
}

/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void DrvRF_24L01_WriteReg(u8 reg, u8 len,u8 *databuf)
�������ܣ�write 24L01 register
���������reg: register address
			   len: write data lengtth
			   databuf:write data buffer
���ز�������
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
u8 DrvRF_24L01_WriteReg(u8 reg, u8 len,u8 *databuf)
{
	u8 i = 0,status;

	SPSS_LOW();
	status =  SPI_RDWRByte(RFCMD_W_REG | reg);

	for(i = 0; i < len; i++)
		status = SPI_RDWRByte(*databuf++);
	SPSS_HIGH();
	return (status);
}
/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�u8 DrvRF_24L01_ReadRegByte(u8 reg)
�������ܣ�write 24L01 register
���������reg: register address
			   len: write data lengtth
			   databuf:write data buffer
���ز�������
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
u8 DrvRF_24L01_ReadRegByte(u8 reg)
{
	u8 status;

	SPSS_LOW();
	status = SPI_RDWRByte(RFCMD_R_REG & reg);
	status = SPI_RDWRByte(RFCMD_NOP);
	SPSS_HIGH();
	return (status);
}

/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void DrvRF_24L01_ReadReg(u8 reg, u8 len,u8 *databuf)
�������ܣ�write 24L01 register
���������reg: register address
			   len: write data lengtth
			   databuf:write data buffer
���ز�������
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
u8 DrvRF_24L01_ReadReg(u8 reg, u8 len,u8 *databuf)
{
	u8 i = 0,status;

	SPSS_LOW();
	status = SPI_RDWRByte(RFCMD_R_REG & reg);

	for(i = 0; i < len; i++)
		*databuf++ = SPI_RDWRByte(RFCMD_NOP);
	SPSS_HIGH();
	return (status);
}

/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void DrvRF_24L01_WriteData(u8 reg, u8 len,u8 *databuf)
�������ܣ�write 24L01 register
���������len: write data lengtth
			   databuf:write data buffer
���ز�����status:  NRF24L01 status register
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
u8 DrvRF_24L01_WriteData(u8 len,u8 *databuf)
{
	u8 i = 0,status;

	//DrvRF_24L01_FLUSH_TX();
	SPSS_LOW();
	status = SPI_RDWRByte(RFCMD_W_TX);

	for(i = 0; i < len; i++)
		SPI_RDWRByte(*databuf++);
	SPSS_HIGH();
	return (status);
}

/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void DrvRF_24L01_ReadData(u8 reg, u8 len,u8 *databuf)
�������ܣ�write 24L01 register
���������len: write data lengtth
			   databuf:write data buffer
���ز�������
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
u8 DrvRF_24L01_ReadData(u8 len,u8 *databuf)
{
	u8 i = 0,status;

	SPSS_LOW();
	status = SPI_RDWRByte(RFCMD_R_RX);

	for(i = 0; i < len; i++)
		*databuf++ = SPI_RDWRByte(RFCMD_NOP);
	SPSS_HIGH();

	return (status);
}


/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void DrvRF_SetRX_Mode(void)
�������ܣ�set the NRF24L01 to Rx mode
���������None
���ز�����None
Ӱ���ȫ�ֱ�����None
*********************************************************************************
********************************************************************************/
void DrvRF_24L01_SetRX_Mode(void)
{
	RF_24L01_CE_CLR();
	
	DrvRF_24L01_WriteReg(REG_RX_ADDR_P0,RFRX_ADR_SIZE,RFRX_ADDRESS);
	DrvRF_24L01_WriteRegByte(REG_CONFIG,(_BV(EN_CRC) | _BV(CRCO) | _BV(PWR_UP) | _BV(PRIM_RX)));			//Rx mode
	
	RF_24L01_CE_SET();
}
/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void DrvRF_SetTX_Mode(void)
�������ܣ�set the NRF24L01 to Tx mode
���������None
���ز�����None
Ӱ���ȫ�ֱ�����None
*********************************************************************************
********************************************************************************/
void DrvRF_24L01_SetTX_Mode(void)
{
	RF_24L01_CE_CLR();
	
	DrvRF_24L01_WriteReg(REG_TX_ADDR,RFTX_ADR_SIZE,RFTX_ADDRESS); //TX
	DrvRF_24L01_WriteReg(REG_RX_ADDR_P0,RFRX_ADR_SIZE,RFTX_ADDRESS);
	DrvRF_24L01_WriteRegByte(REG_CONFIG,(_BV(EN_CRC) | _BV(CRCO) | _BV(PWR_UP))); 		//Tx mode
	
	RF_24L01_CE_SET();
	Delay_us(160);
}
/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�u8 DrvRF_24L01_RxPacket(u8* rx_buf)
�������ܣ�read Rx data
���������None
���ز�����None
Ӱ���ȫ�ֱ�����None
*********************************************************************************
********************************************************************************/
u8 DrvRF_24L01_RxPacket(u8* rx_buf)
{
	u8 ret_value = 0,status;

	status = DrvRF_24L01_ReadRegByte(REG_STATUS);
	if(status & _BV(RX_DR))
		{
			RF_24L01_CE_CLR();
			DrvRF_24L01_ReadData(RFRX_PLOAD_SIZE,rx_buf);
			ret_value = 1;     //read data compelet flag
		}
	DrvRF_24L01_WriteRegByte(REG_STATUS,status);		//write RX_DR,TX_DS,MAX_PT clear the int
	return ret_value;
}
/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�u8 DrvRF_24L01_TxPacket(u8* rx_buf)
�������ܣ�read Rx data
���������None
���ز�����None
Ӱ���ȫ�ֱ�����None
*********************************************************************************
********************************************************************************/
void DrvRF_24L01_TxPacket(u8* tx_buf)
{
	RF_24L01_CE_CLR();			//standby I mode
	//DrvRF_24L01_WriteReg(REG_RX_ADDR_P0,RFTX_ADR_SIZE,RFTX_ADDRESS);
	DrvRF_24L01_WriteData(RFTX_PLOAD_SIZE,tx_buf);
	RF_24L01_CE_SET();
}

/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void DrvRF_24L01_Init(void)
�������ܣ�init 24L01
���������None
���ز�������
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
void DrvRF_24L01_Init(void)
{
	u8 IDBuf[5];
	SPI_MasterInit(E_SPI_CLK_PRE4,E_SPI_MODE0);
	RF_24L01_DDR |= RF_24L01_CE;
	
	RF_24L01_CE_CLR();				//chip enable
	DrvRF_24L01_ReadReg(REG_RX_ADDR_P0,RFRX_ADR_SIZE,IDBuf);
	DrvRF_24L01_ReadReg(REG_RX_ADDR_P1,RFRX_ADR_SIZE,IDBuf);
	DrvRF_24L01_ReadReg(REG_RX_ADDR_P2,RFRX_ADR_SIZE,IDBuf);
	DrvRF_24L01_ReadReg(REG_RX_ADDR_P3,RFRX_ADR_SIZE,IDBuf);
	DrvRF_24L01_ReadReg(REG_RX_ADDR_P4,RFRX_ADR_SIZE,IDBuf);
	DrvRF_24L01_ReadReg(REG_RX_ADDR_P5,RFRX_ADR_SIZE,IDBuf);
	DrvRF_24L01_ReadReg(REG_TX_ADDR,RFRX_ADR_SIZE,IDBuf);

	DrvRF_24L01_WriteRegByte(REG_EN_AA,_BV(ENAA_P0));		//pipe0 auto ack enable
	DrvRF_24L01_WriteRegByte(REG_EN_RXADDR,_BV(ERX_P0));	//enable pipe0
	DrvRF_24L01_WriteRegByte(REG_RF_CH,0);					//2.4GHz
	DrvRF_24L01_WriteRegByte(REG_RX_PW_P0,RFRX_PLOAD_SIZE); //set the recive data length
	DrvRF_24L01_WriteRegByte(REG_RF_SETUP,(_BV(RF_DR) | _BV(RF_PWR0) | _BV(RF_PWR1) | _BV(LNA_HCURR)));//1MHz 0dBm
	
	RF_24L01_CE_SET();

}
