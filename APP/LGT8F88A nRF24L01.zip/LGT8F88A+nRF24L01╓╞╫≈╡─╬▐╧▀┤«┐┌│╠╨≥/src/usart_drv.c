/*****************************************************************************
 **	  						The C file for LGT8F88A Microprocessors  			        **
 **																	    		**
 **   						      Copyright(C) 2013, Green Tec.						**
 **  								 All rights reserved.								**
 ******************************************************************************
 **	  filename		: usart_drv.c													**
 **     version 		: v1.0														**
 **     created by 	: sean														** 
 **	  date		: 2013-5-13													**
 **	  used for mg8f88a															**
******************************************************************************/
#include "usart_drv.h"
#include "rf_drv.h"

P_USART0_CallBack p_usart0rxccallback;
P_USART0_CallBack p_usart0txccallback;
P_USART0_CallBack p_usart0udrcallback;

u8 smpl_RxBuf[5];
u8 smpl_TxBuf[] = " : LGT\r\n>>=";

static void USART0_RXHandle(void);

/****************************************************************************/
/****************************************************************************
Function Name :  void USART_Init(u32 eBaud, E_USART_MODE eMode, E_USART_FRAME eFrame,E_USART_PARITY eParity,u32 emclk)
�������ƣ�
�������ܣ�Init USART
���������eBaud:  baud
			      eMode: USART mode
			      eFrame:frame length
			      eParity: USART parity
			      eMclk:	 MCU main clk
���ز�������
Ӱ���ȫ�ֱ�������
****************************************************************************/
void USART_Init(u32 eBaud, E_USART_MODE eMode, E_USART_FRAME eFrame,E_USART_PARITY eParity,u32 eMclk)
{	
	u8 esrge;

	esrge = SREG;
	CLI();
	UCSR0A = 0;//stop USART
	UCSR0B = 0;
	UCSR0C = 0;

	if(eMode == E_USART_ASYNC || eMode == E_USART_SYNCM)
		{
			if(eFrame == E_USART_FLEN9)
				{
					UCSR0C = (eMode << 6) | (eParity << 4) | (0x03 << 1);
					UCSR0B |= _BV(UCSZ02);
				}
			else		
				UCSR0C = (eMode << 6) | (eParity << 4) | (eFrame << 1);
		}
	else 		//USPI mode
		{
			UCSR0C = (eMode << 6) | _BV(DORD) | E_USPI_MODE0;			//spi mode0
		}
	//
	if(eMode == E_USART_SYNCM || eMode == E_USART_SPIMS) 				//synchronouse mode
		DDRD |= _BV(PD4);
	else if(eMode == E_USART_SPISL)
		DDRD &= ~(_BV(PD4));
	//set baud
	UBRR0H = ((eMclk/16)/eBaud-1)>>8;
	UBRR0L = ((eMclk/16)/eBaud-1)&255;

	UCSR0B |= _BV(RXEN0) | _BV(TXEN0);			//enable Rx and Tx		

	SREG = esrge;
	USART_IntSet(USART0_RXHandle,E_USART0_INT_RXC);
	mprintf("usart init\r\n");
}

/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void Uart_IntSet(P_USART0_RXCCallBack pcallback,E_USART0_INT_TYPE eIntype)
�������ܣ�
���������uchar data
���ز�������
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
void USART_IntSet(P_USART0_CallBack pcallback,E_USART0_INT_TYPE eIntype)
{
	switch(eIntype)
		{	
			case E_USART0_INT_RXC:
				UCSR0B |= _BV(RXCIE0);
				p_usart0rxccallback = pcallback;
				break;
			case E_USART0_INT_TXC:
				UCSR0B |= _BV(TXCIE0);
				p_usart0txccallback = pcallback;
				break;
			case E_USART0_INT_UDR:
				UCSR0B |= _BV(UDRIE0);
				p_usart0udrcallback = pcallback;
				break;
			default:break;
		}
}



/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void USART_IntDisable(E_USART0_INT_TYPE eIntype)
�������ܣ�
���������eIntype:  usart interrupt type
���ز�������
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
void USART_IntDisable(E_USART0_INT_TYPE eIntype)
{
	switch(eIntype)
		{	
			case E_USART0_INT_RXC:
				UCSR0B &= ~_BV(RXCIE0);
				p_usart0rxccallback = PNULL;
				break;
			case E_USART0_INT_TXC:
				UCSR0B &= ~_BV(TXCIE0);
				p_usart0txccallback = PNULL;
				break;
			case E_USART0_INT_UDR:
				UCSR0B &= ~_BV(UDRIE0);
				p_usart0udrcallback = PNULL;
				break;
			default:break;
		}
}

/****************************************************************************/
/****************************************************************************
Function Name :  void USART_SendByte(u8 data)
�������ܣ�usart send byte
���������data:
���ز�������
Ӱ���ȫ�ֱ�������
****************************************************************************/
void USART_SendByte(u8 data)
{
	while(!(UCSR0A & _BV(UDRE0)));				//check send mode
	UDR0 = data;
}

/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�uchar UART_ReceiveByte(void)
�������ܣ�
�����������
���ز�����UDRֵ
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
u8 USART_ReceiveByte(void)
{/*receiving frames 5 to 8 data bits*/
	while( !(UCSR0A & (1<<RXC0)) );//�ȴ��������loop_until_bit_is_set(UCSR0A,RXC0);//
	return UDR0;
}

/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void UART_SendStr(const char *str)
�������ܣ�
���������str
���ز�������
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
void USART_SendStr(const char *str)
{
  	while(1)
	   { 
	      if(*str == '\0') break;
		  USART_SendByte(*str++); 
	    }
}


/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void mprintf(const char *str)
�������ܣ�
���������str
���ز�������
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
void mprintf(const char *str, ...)//const
{

  char string[64];	
  va_list ap;

  va_start(ap,str);
  vsprintf(string,str,ap);
  USART_SendStr(string);
  va_end(ap);

}
/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�static void USART0_RXHandle(void)
�������ܣ�
���������None
���ز�������
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
static void USART0_RXHandle(void)
{
	send_buf[0] = UDR0;
	//USART_SendByte(send_buf[0]);
	DrvRF_24L01_TxPacket(send_buf);
	DrvRF_24L01_SetTX_Mode();
}
/********************************************************************************
*********************************************************************************
Function Name:
�������ƣ�void USART_Demo(u32 eMCLK)
�������ܣ�
���������str
���ز�������
Ӱ���ȫ�ֱ�������
*********************************************************************************
********************************************************************************/
void USART_Demo(u32 eMCLK)
{
	USART_Init(115200,E_USART_ASYNC,E_USART_FLEN8,E_USART_DIS,eMCLK);
	//USART_IntSet(USART0_RXHandle,E_USART0_INT_RXC);			//eanble rx int
	mprintf("88A USART Init Ok! Hello Word.\r\n");
	switch(eMCLK)
		{
			case f_cpu1M:
				mprintf("MCLK@1MHz\r\n");
				break;
			case f_cpu2M:
				mprintf("MCLK@2MHz\r\n");
				break;
			case f_cpu4M:
				mprintf("MCLK@4MHz\r\n");
				break;
			case f_cpu8M:
				mprintf("MCLK@8MHz\r\n");
				break;
			case f_cpu10M:
				mprintf("MCLK@10MHz\r\n");
				break;
			case f_cpu11M:
				mprintf("MCLK@11MHz\r\n");
				break;
			case f_cpu16M:
				mprintf("MCLK@16MHz\r\n");
				break;
			case f_cpu20M:
				mprintf("MCLK@20MHz\r\n");
				break;
			case f_cpu24M:
				mprintf("MCLK@24MHz\r\n");
				break;
			case f_cpu32M:
				mprintf("MCLK@32MHz\r\n");
				break;
			case f_cpu40M:
				mprintf("MCLK@40MHz\r\n");
				break;
			case f_cpu64M:
				mprintf("MCLK@64MHz\r\n");
				break;
		}
}



//
ISR(SIG_USART_RECV)
{
	if(p_usart0rxccallback != PNULL)
		p_usart0rxccallback();
}



