/*****************************************************************************
 **	  						The C file for LGT8F88A Microprocessors  			        **
 **																	    		**
 **   						      Copyright(C) 2013, Green Tec.						**
 **  								 All rights reserved.								**
 ******************************************************************************
 **	  filename		: exint_drv.c													**
 **     version 		: v1.0														**
 **     created by 	: sean														** 
 **	  date		: 2013-4-24													**
 **	  used for mg8f88a															**
******************************************************************************/
#include "exint_drv.h"
//#include "power_drv.h"

//E_SLEEP_MODE	sleepmode;

P_EXINT_CallBack p_exint1_callback;
/****************************************************************************/
/****************************************************************************
Function Name :  void ExInt_Enable(E_INT_NUMB eIntNumb, E_INT_TRIGTYPE eIntType, P_EXINT_CallBack pexintcallback)
�������ƣ�
�������ܣ�enable WDT
���������resetEn: 1 enable reset 0 disable
			      intEn:	     1 enable int     0 disable
			      clkpre:     clock prescale
���ز�������
Ӱ���ȫ�ֱ�������
****************************************************************************/
void ExInt_Enable(E_INT_NUMB eIntNumb, E_INT_TRIGTYPE eIntType, P_EXINT_CallBack pexintcallback)
{
	switch(eIntNumb)
		{
			case E_INT_INT0:
				EICRA = (EICRA & ~INT0_ISC_MASK) | (eIntType << ISC00);
				p_exint1_callback = pexintcallback;
				INT0_CLEAR_FLAG();
				INT0_ENABLE();
				break;
			case E_INT_INT1:
				EICRA = (EICRA & ~INT1_ISC_MASK) | (eIntType << ISC10);
				INT1_CLEAR_FLAG();
				INT1_ENABLE();
				break;
			default: break;
		}
}
//external interrupt0 
ISR(SIG_INTERRUPT0)
{
	
	if(p_exint1_callback != NULL)
		p_exint1_callback();
}
//external interrupt1	

ISR(SIG_INTERRUPT1)
{
	NOP();
}


/****************************************************************************/
/****************************************************************************
Function Name :   void PinChangeInt_Enable(E_PCI_NUMB ePCINumb,E_PCI_PORT ePCIPort, E_PCI_ENDIS ePCIed)
�������ƣ�
�������ܣ�enable WDT
���������resetEn: 1 enable reset 0 disable
			      intEn:	     1 enable int     0 disable
			      clkpre:     clock prescale
���ز�������
Ӱ���ȫ�ֱ�������
****************************************************************************/
void PinChangeInt_Enable(E_PCI_NUMB ePCINumb,E_PCI_PORT ePCIPort, E_PCI_ENDIS ePCIed)
{
	switch(ePCIPort)
		{
			case E_PCI_PORTB:
				if(ePCIed)
					{
						PCMSK0 |= (1 << ePCINumb);
						PCICR |= (1 << PCIE0);
					}
				else
					{
						PCMSK0 &= (1 << ePCINumb);
						PCICR &= (1 << PCIE0);
					}
				break;
			case E_PCI_PORTC:
				if(ePCIed)
					{
						PCMSK1 |= (1 << ePCINumb);
						PCICR |= (1 << PCIE1);
					}
				else
					{
						PCMSK1 &= (1 << ePCINumb);
						PCICR &= (1 << PCIE1);
					}
				break;
			case E_PCI_PORTD:
				if(ePCIed)
					{
						PCMSK2 |= (1 << ePCINumb);
						PCICR |= (1 << PCIE2);
					}
				else
					{
						PCMSK2 &= (1 << ePCINumb);
						PCICR &= (1 << PCIE2);
					}
				break;
			case E_PCI_PORTE:
				if(ePCIed)
					{
						PCMSK3 |= (1 << ePCINumb);
						PCICR |= (1 << PCIE3);
					}
				else
					{
						PCMSK3 &= (1 << ePCINumb);
						PCICR &= (1 << PCIE3);
					}
				break;
					
		}
}

ISR(SIG_PIN_CHANGE0)
{
	NOP();
}
