/*****************************************************************************
 **	  						The C file for LGT8F88A Microprocessors  		         **
 **																	**
 **   						      Copyright(C) 2013, Green Tec.						**
 **  								 All rights reserved.						**
 ******************************************************************************
 **	  filename		: lgt88a_rf.c											**
 **     version 		: v1.0												**
 **     created by 	: sean												** 
 **	  date		: 2013-9-3											**
 **	  used for mg8f88a													**
******************************************************************************/
#include "mcu_def.h"
#include "base.h"
#include "rf_drv.h"
#include "usart_drv.h"
#include "exint_drv.h"
u8 send_buf[32] = {0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x3A,0x3B,0x3C,0x3D,0x3E,0x3F
									 ,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x3A,0x3B,0x3C,0x3D,0x3E,0x3F};
u8 recieve_buf[32] = {};

static void ExInt0_Handle(void);

/****************************************************************************/
/****************************************************************************
Function Name :  int main(void)
�������ƣ�
�������ܣ�
���������None
���ز�����None
Ӱ���ȫ�ֱ�����None
****************************************************************************/
int main(void)
{
	//volatile u8 status,i;
	//change MCLK prescalevolatile u16 counter = 0;
	CLKPR = _BV(CLKPCE);
	CLKPR = 0;
	Delay_ms(1);
	USART_Init(19200,E_USART_ASYNC,E_USART_FLEN8,E_USART_DIS,f_cpu32M);
	ExInt_Enable(E_INT_INT0,E_INT_FALLING,ExInt0_Handle);
	
	DrvRF_24L01_Init();
	DrvRF_24L01_SetRX_Mode();

	SEI();
	while(1)
		{
			/*if(counter++ > 20000)
				{
					counter = 0;
					//DrvRF_24L01_WriteData(RFRX_PLOAD_SIZE,send_buf);
					
					DrvRF_24L01_TxPacket(send_buf);
					DrvRF_24L01_SetTX_Mode();
				}
			if(!(PINB & RF_24L01_IRQ))
				{
					
					status = DrvRF_24L01_ReadRegByte(REG_STATUS);
					if(status & _BV(RX_DR))
						{	
							DrvRF_24L01_WriteRegByte(REG_STATUS,_BV(RX_DR));						
							DrvRF_24L01_ReadData(RFRX_PLOAD_SIZE,recieve_buf);
							for(i = 0; i < RFRX_PLOAD_SIZE; i++)
								USART_SendByte(recieve_buf[i]);
						}
					if(status & _BV(TX_DS))
						{
							DrvRF_24L01_WriteRegByte(REG_STATUS,_BV(TX_DS));
							DrvRF_24L01_SetRX_Mode();
						}
					if(status & _BV(MAX_RT))
						{
							DrvRF_24L01_WriteRegByte(REG_STATUS,_BV(MAX_RT));
							DrvRF_24L01_SetRX_Mode();
						}
						
				}*/
		}

	return 1;
}

/****************************************************************************/
/****************************************************************************
Function Name :  int main(void)
�������ƣ�
�������ܣ�
���������None
���ز�����None
Ӱ���ȫ�ֱ�����None
****************************************************************************/
void ExInt0_Handle(void)
{
	u8 status,i;

	if(!(PIND & RF_24L01_IRQ))
		{
			
			status = DrvRF_24L01_ReadRegByte(REG_STATUS);
			if(status & _BV(RX_DR))
				{	
					DrvRF_24L01_WriteRegByte(REG_STATUS,_BV(RX_DR));						
					DrvRF_24L01_ReadData(RFRX_PLOAD_SIZE,recieve_buf);
					for(i = 0; i < RFRX_PLOAD_SIZE; i++)
						USART_SendByte(recieve_buf[i]);
				}
			if(status & _BV(TX_DS))
				{
					DrvRF_24L01_WriteRegByte(REG_STATUS,_BV(TX_DS));
					DrvRF_24L01_SetRX_Mode();
				}
			if(status & _BV(MAX_RT))
				{
					DrvRF_24L01_WriteRegByte(REG_STATUS,_BV(MAX_RT));
					DrvRF_24L01_SetRX_Mode();
				}
				
		}
}
