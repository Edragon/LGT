/*****************************************************************************
 **	  						The C file for LGT8F88A Microprocessors  			        **
 **																	    		**
 **   						      Copyright(C) 2013, Green Tec.						**
 **  								 All rights reserved.								**
 ******************************************************************************
 **	  filename		: base.h														**
 **     version 		: v1.0														**
 **     created by 	: sean														** 
 **	  date		: 2013-4-24													**
 **	  used for mg8f88a															**
******************************************************************************/

#ifndef _BASE_H
#define _BASE_H

#include "mcu_def.h"
//
u16 Data_Average(u16 *pDataBuf, u8 length);
uint32 Data_Add(uint16 *buffer, uint8 size);
uint16 Data_Max(uint16 *buffer, uint8 size);
uint16 Data_Min(uint16 *buffer, uint8 size);

void Delay_ms(unsigned int ms);
void Delay_us(unsigned int us);
void Memory_Set(u8* buf, u16 size, u8 data);

#endif
/****************************************************************************************
*************************************End of File*******************************************/

