/*****************************************************************************
 **	  						The C file for LGT8F88A Microprocessors  			        **
 **																	    		**
 **   						      Copyright(C) 2013, Green Tec.						**
 **  								 All rights reserved.								**
 ******************************************************************************
 **	  filename		: usart_drv.h													**
 **     version 		: v1.0														**
 **     created by 	: sean														** 
 **	  date		: 2013-4-24													**
 **	  used for mg8f88a															**
******************************************************************************/

#ifndef _USART_DRV_H
#define _USART_DRV_H

#include "mcu_def.h"
//USART work mode
typedef enum{
	E_USART_ASYNC,			//USART asynchronous mode
	E_USART_SYNCM,			//USART synchronous mode
	E_USART_SPISL,			//USART SPI slave mode
	E_USART_SPIMS,			//USART SPI master mode
}E_USART_MODE;
//USART parity
typedef enum{
	E_USART_DIS,			//disabel parity
	E_USART_NONE,			//NULL
	E_USART_EVEN,			//enable even parity
	E_USART_ODD,			//enable odd parity
}E_USART_PARITY;
//USART frame character length
typedef enum{
	E_USART_FLEN5,			//5bit frame length
	E_USART_FLEN6,			//6bit frame length
	E_USART_FLEN7,			//7bit frame length
	E_USART_FLEN8,			//8bit frame length
	E_USART_FLEN9 = 7,		//9bit frame length
}E_USART_FRAME;
//USPI Mode
typedef enum{				//start:			 end
	E_USPI_MODE0,			//rising edge sample, falling edge set
	E_USPI_MODE1,			//rising edge set,falling edge sample
	E_USPI_MODE2,			//falling edge sample, rising edge set
	E_USPI_MODE3,			//falling edge set,  rising edge sample
}E_USPI_MODE;	

//interrupt define
typedef enum{
	E_USART0_INT_RXC,			//receive end interrupt
	E_USART0_INT_TXC,			//trancive end interrupt
	E_USART0_INT_UDR,			//data reg empty interrupt
}E_USART0_INT_TYPE;

typedef void(*P_USART0_CallBack)(void);		//usart0 interrupt function type


void USART_Init(u32 eBaud, E_USART_MODE eMode, E_USART_FRAME eFrame,E_USART_PARITY eParity,u32 eMclk);
void USART_IntSet(P_USART0_CallBack pcallback,E_USART0_INT_TYPE eIntype);
void USART_SendByte(u8 data);
u8 USART_ReceiveByte(void);
void USART_SendStr(const char *str);
void mprintf(const char *str, ...);
void USART_Demo(u32 eMCLK);

#endif
/****************************************************************************************
*************************************End of File*******************************************/

