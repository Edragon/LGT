/*****************************************************************************
 **	  					The H file for LGT8F88A Microprocessors  			 	**
 **																	**
 **   						     Copyright(C) 2013, Green Tec.						**
 **  							 All rights reserved.							**
 ******************************************************************************
 **	  filename		: rf_drv.h												**
 **     version 		: v1.0												**
 **     created by 	: sean												** 
 **	  date		: 2013-9-3											**
 **	  used for mg8f88a													**
******************************************************************************/

#ifndef _RF_DRV_H
#define _RF_DRV_H

#include "mcu_def.h"
#define RF_24L01_DDR		DDRB
#define RF_24L01_CE			1 << PB0				//chip enable
#define RF_24L01_IRQ		1 << PD2				//IRQ port  Exint0
#define RF_24L01_CE_SET()	PORTB |= RF_24L01_CE
#define RF_24L01_CE_CLR()	PORTB &= ~RF_24L01_CE

#define RFCMD_R_REG			0x1F			//read register 5bit memory map address
#define RFCMD_W_REG			0x20			//write register 5bit memory map address
#define RFCMD_R_RX			0x61			//read RX payload  1-32bytes LSByte first
#define RFCMD_W_TX			0xA0			//write Tx payload 1-32bytes LSByte first start at byte0
#define RFCMD_FLUSH_TX		0xE1			//Flush Tx FIFO
#define RFCMD_FLUSH_RX		0xE2			//Flush Rx FIFO
#define RFCMD_REUSE_TX_PL	0xE3			//used for a PTX device
#define RFCMD_NOP			0xFF			//No operation


//memory map
#define REG_CONFIG		0x00			//configuration register
	#define MASK_RX_DR	6				//mask interrupt caused by	RX_RD	
	#define MASK_TX_DS	5				//mask interrupt caused by	TX_DS	
	#define MASK_MAX_RT	4				//mask interrupt caused by	MAX_MT
	#define EN_CRC		3				//enable CRC
	#define CRCO		2				//CRC encoding scheme 0-1byte 1-2byte
	#define PWR_UP		1				//1-power up 0-power down
	#define PRIM_RX		0				//1-PRX 0-PTX
#define REG_EN_AA		0x01			//enable auto ack	
	#define ENAA_P5		5				//enable auto ack data pipe 5
	#define ENAA_P4		4				//enable auto ack data pipe 4
	#define ENAA_P3		3				//enable auto ack data pipe 3
	#define ENAA_P2		2				//enable auto ack data pipe 2
	#define ENAA_P1		1				//enable auto ack data pipe 1
	#define ENAA_P0		0				//enable auto ack data pipe 0
#define REG_EN_RXADDR	0x02			//enable RX addresses
	#define ERX_P5		5				//enable data pipe 5
	#define ERX_P4		4				//enable data pipe 4
	#define ERX_P3		3				//enable data pipe 3
	#define ERX_P2		2				//enable data pipe 2
	#define ERX_P1		1				//enable data pipe 1
	#define ERX_P0		0				//enable data pipe 0
#define REG_SETUP_AW	0x03			//setup of address width
	#define AW1			1			 	//00-illegal 01-3bytes 10-4bytes 11-5bytes
	#define AW0			0
#define REG_SETUP_RETR	0x04			//setup of automatic retransmission
	#define ARD			7				//auto re-transmit delay
	#define ARC			3				//auto retransmit count
#define REG_RF_CH		0x05			//RF channel
	#define RF_CH6		6				//set the frequency channel operates on
	#define RF_CH5		5
	#define RF_CH4		4
	#define RF_CH3		3
	#define RF_CH2		2
	#define RF_CH1		1
	#define RF_CH0		0
#define REG_RF_SETUP	0x06			//RF setup register
	#define PLL_LOCK	4				//force pll lock signal
	#define RF_DR		3				//data rate 0-1Mbps 1-2Mbps
	#define RF_PWR1		2
	#define RF_PWR0		1				//00-18dBm 01-12dBm 10-6dBm 11-0dBm
	#define LNA_HCURR	0				//setup LNA gain
#define REG_STATUS		0x07			//status register
	#define RX_DR		6				//data ready RX FIFO interrupt
	#define TX_DS		5				//Data sent Tx FIFO interrupt
	#define MAX_RT		4				//maximum number of TX retries interrupt
	#define RX_P_NO2	3				//data pipe number avaliable for RX
	#define RX_P_NO1	2				//111- Rx FIFO empty
	#define RX_P_NO0	1
	#define TX_FULL		0				//Tx FIFO full flag 1-full
#define REG_OBSERVE_TX	0x08			//transmit observe register
	#define PLOS_CNT	7				//packet loss counter  7:4
	#define ARC_CNT		3				//current value on resent counter 3:0
#define REG_CD			0x09			//
	#define CD			0				//carrier detect
#define REG_RX_ADDR_P0	0x0A			//5bytes
#define REG_RX_ADDR_P1	0x0B		
#define REG_RX_ADDR_P2	0x0C		
#define REG_RX_ADDR_P3	0x0D		
#define REG_RX_ADDR_P4	0x0E		
#define REG_RX_ADDR_P5	0x0F		
#define REG_TX_ADDR		0x10			//trasmit address  PTX same as P0
#define REG_RX_PW_P0	0x11			//number of bytes in RX payload in data pipe0
#define REG_RX_PW_P1	0x12			//number of bytes in RX payload in data pipe1
#define REG_RX_PW_P2	0x13			//number of bytes in RX payload in data pipe2
#define REG_RX_PW_P3	0x14			//number of bytes in RX payload in data pipe3
#define REG_RX_PW_P4	0x15			//number of bytes in RX payload in data pipe4
#define REG_RX_PW_P5	0x16			//number of bytes in RX payload in data pipe5
#define REG_FIFO_STATUS	0x17			//FIFO status register
	#define TX_REUSE	6				//reuse last sent data packet 1
	#define FTX_FULL	5				//TX FIFO full flag
	#define TX_EMPTY	4				//
	#define RX_FULL		1				//RX FIFO full flag
	#define RX_EMPTY	0				//

#define RFTX_ADR_SIZE			5
#define RFRX_ADR_SIZE			5
#define RFRX_PLOAD_SIZE			1
#define RFTX_PLOAD_SIZE			1

extern u8 send_buf[32];

//Function
u8 DrvRF_24L01_WriteRegByte(u8 reg, u8 regdata);
u8 DrvRF_24L01_WriteReg(u8 reg, u8 len,u8 *databuf);
u8 DrvRF_24L01_ReadRegByte(u8 reg);
u8 DrvRF_24L01_ReadReg(u8 reg, u8 len,u8 *databuf);
u8 DrvRF_24L01_WriteData(u8 len,u8 *databuf);
u8 DrvRF_24L01_ReadData(u8 len,u8 *databuf);
void DrvRF_24L01_SetRX_Mode(void);
void DrvRF_24L01_SetTX_Mode(void);
u8 DrvRF_24L01_RxPacket(u8* rx_buf);
void DrvRF_24L01_TxPacket(u8* tx_buf);
void DrvRF_24L01_Init(void);

#endif
/****************************************************************************************
*************************************End of File*******************************************/

