/*****************************************************************************
 **	  						The H file for LGT8F88A Microprocessors  			        **
 **																	    		**
 **   						      Copyright(C) 2013, Green Tec.						**
 **  								 All rights reserved.								**
 ******************************************************************************
 **	  filename		: wdt_drv.h													**
 **     version 		: v1.0														**
 **     created by 	: sean														** 
 **	  date		: 2013-4-24													**
 **	  used for mg8f88a															**
******************************************************************************/

#ifndef _EXINT_DRV_H
#define _EXINT_DRV_H

#include "mcu_def.h"

//
typedef enum{
	E_INT_LOWLEVEL,			//
	E_INT_CHANGE,				//falling & rising edge
	E_INT_FALLING,				//falling edge
	E_INT_RISING,				//rising edge
}E_INT_TRIGTYPE;


typedef enum{
	E_INT_INT0,
	E_INT_INT1,
}E_INT_NUMB;

//Pin Change Interrupt
typedef enum{
	E_PCI_PCINT0 = 0,
	E_PCI_PCINT1,
	E_PCI_PCINT2,
	E_PCI_PCINT3,
	E_PCI_PCINT4,
	E_PCI_PCINT5,
	E_PCI_PCINT7,
	E_PCI_PCINT8 = 0,
	E_PCI_PCINT9,
	E_PCI_PCINT10,
	E_PCI_PCINT11,
	E_PCI_PCINT12,
	E_PCI_PCINT13,
	E_PCI_PCINT14,
	E_PCI_PCINT15,
	E_PCI_PCINT16 = 0,
	E_PCI_PCINT17,
	E_PCI_PCINT18,
	E_PCI_PCINT19,
	E_PCI_PCINT20,
	E_PCI_PCINT21,
	E_PCI_PCINT22,
	E_PCI_PCINT23,
	E_PCI_PCINT24,
	E_PCI_PCINT25 = 0,
	E_PCI_PCINT26,
	E_PCI_PCINT27,
	E_PCI_PCINT28,
	E_PCI_PCINT29,
	E_PCI_PCINT30,
}E_PCI_NUMB;

typedef enum{
	E_PCI_PORTB,
	E_PCI_PORTC,
	E_PCI_PORTD,
	E_PCI_PORTE,
}E_PCI_PORT;

typedef enum{
	E_PCI_DIS,
	E_PCI_EN,
}E_PCI_ENDIS;


#define INT0_ISC_MASK		0x03
#define INT1_ISC_MASK		0x0C

#define INT0_ENABLE()		EIMSK |= _BV(INT0)
#define INT1_ENABLE()		EIMSK |= _BV(INT1)
#define INT0_CLEAR_FLAG()	EIFR  |= _BV(INTF0)
#define INT1_CLEAR_FLAG()	EIFR  |= _BV(INTF1)
typedef void(*P_EXINT_CallBack)(void);		//external interrupt function type


void ExInt_Enable(E_INT_NUMB eIntNumb, E_INT_TRIGTYPE eIntType, P_EXINT_CallBack pexintcallback);
void PinChangeInt_Enable(E_PCI_NUMB ePCINumb,E_PCI_PORT ePCIPort, E_PCI_ENDIS ePCIed);

#endif
/****************************************************************************************
*************************************End of File*******************************************/

