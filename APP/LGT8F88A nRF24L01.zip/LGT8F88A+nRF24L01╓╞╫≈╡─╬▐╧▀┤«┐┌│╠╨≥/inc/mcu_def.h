/*****************************************************************************
 **	  						The C file for LGT8F88A Microprocessors  			        **
 **																	    		**
 **   						      Copyright(C) 2013, Green Tec.						**
 **  								 All rights reserved.								**
 ******************************************************************************
 **	  filename		: mcu_def.h												**
 **     version 		: v1.0														**
 **     created by 	: sean														** 
 **	  date		: 2013-4-24													**
 **	  used for mg8f88a															**
******************************************************************************/

#ifndef _MCU_DEF_H
#define _MCU_DEF_H

#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <avr/wdt.h>
#include <util/twi.h>

#include <math.h>
//#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <inttypes.h>
#include <setjmp.h>
#include <assert.h>

#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include "avr/sfr_defs.h"


//#include "macros.h"


#define NOP()			asm("nop")
#define CLI()			asm("cli")
#define SEI()			asm("sei")
#define WDR()			wdt_reset()
#define SLEEP()			asm("sleep")

typedef unsigned char	uint8;
typedef unsigned int	uint16;
typedef unsigned long  uint32;

typedef unsigned char	u8;
typedef unsigned int	u16;
typedef unsigned long  u32;

#define f_cpu  		32000000LU			//16MHz
#define f_cpu64M	64000000LU			//64MHz
#define f_cpu40M	40000000LU			//40MHz
#define f_cpu32M	32000000LU			//32MHz
#define f_cpu24M	24000000LU			//24MHz
#define f_cpu20M	20000000LU			//20MHz
#define f_cpu16M	16000000LU			//16MHz
#define f_cpu12M	12000000LU			//12MHz
#define f_cpu11M	11059200LU			//11MHz
#define f_cpu10M	10000000LU			//10MHz
#define f_cpu8M		8000000LU				//8MHz
#define f_cpu4M		4000000LU				//4MHz
#define f_cpu2M		2000000LU				//2MHz
#define f_cpu1M		1000000LU				//1MHz

#define NULL 	((void *)0)
#define PNULL 	((void *)0)

//
//Port pin configurations
//DDxn  PORTxn  PUD  I/O  PULL-UP  Comment
//0        0             X      In     N             Tri_state
//0        1             0      In     Y              Pxn will source current if ext. pulled low
//0        1             1      In     N              Tri-state
//1        0             X      Out    N              Output low
//1        1             X      Out    N              Output high
/*port output control*/
#define PINX_SET(portx,ddrx,numb)		do{ddrx |= _BV(numb);	portx |= _BV(numb)};while(0)		//set to 1
#define PINX_CLEAR(portx,ddrx,numb)	do{ddrx |= _BV(numb);	portx &= ~(_BV(numb))};while(0)	//clear to 0
#define PINX_NOT(portx,ddrx,numb)		do{ddrx |= _BV(numb);	portx ^= _BV(numb)};while(0)		//not 


extern u8 	Disp_Numb;		//character dispaly bit
extern u32 	Disp_Char;		//8bit character
extern u8	Int0_Change_count;	//
extern u8	Change_en;		//



#endif
/****************************************************************************************
*************************************End of File*******************************************/

