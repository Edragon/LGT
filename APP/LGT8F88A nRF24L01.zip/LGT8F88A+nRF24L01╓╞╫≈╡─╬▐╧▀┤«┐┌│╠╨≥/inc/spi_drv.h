/*****************************************************************************
 **	  						The C file for LGT8F88A Microprocessors  			        **
 **																	    		**
 **   						      Copyright(C) 2013, Green Tec.						**
 **  								 All rights reserved.								**
 ******************************************************************************
 **	  filename		: led_drv.h													**
 **     version 		: v1.0														**
 **     created by 	: sean														** 
 **	  date		: 2013-4-24													**
 **	  used for mg8f88a															**
******************************************************************************/

#ifndef _SPI_DRV_H
#define _SPI_DRV_H

#include "mcu_def.h"
/*
SPSS ==> PB2
MOSI ==> PB3
MISO ==> PB4
SCK   ==> PB5*/

#define DDR_SS		DDB2
#define DDR_MOSI	DDB3
#define DDR_MISO	DDB4
#define DDR_SCK		DDB5

#define PORT_SS		PB2
#define SPSS_HIGH()	PORTB |= _BV(PORT_SS)
#define SPSS_LOW()		PORTB &= ~(_BV(PORT_SS))

/*SPI mode
CPOL	CPHA	start edge	end edge		SPIMode
0		0		sample rising	set falling		o
0		1		set rising		sample falling	1
1		0		sample falling	set rising		2
1		1		set falling		sample rising	3*/
typedef enum{
	E_SPI_MODE0,
	E_SPI_MODE1,
	E_SPI_MODE2,
	E_SPI_MODE3
}E_SPI_MODE;	//bit2 CPHA


/*SPI CLK prescale*/
typedef enum{
	E_SPI_CLK_PRE4,
	E_SPI_CLK_PRE16,
	E_SPI_CLK_PRE64,
	E_SPI_CLK_PRE128
}E_SPI_CLK;

/*W25X64 Operate command*/
#define W25X64_CMD_WREN			0x06		//write enable-- must be set prior to 1>page program 2>sector erase 3>block erase 4>chip erase 5>write status register
#define W25X64_CMD_WRDIS			0x04		//write disable
#define W25X64_CMD_RDSTREG		0x05		//read status register
#define W25X64_CMD_WRSTREG		0x01		//write status register
#define W25X64_CMD_RDDATA			0x03		//read data	A23-A0	D7-D0 (next byte data)
#define W25X64_CMD_FASTRD			0x0B		//fast read	A23-A0	(Dummy) D7-D0 (next byte data)
#define W25X64_CMD_DUALOUT		0x3B		//fast read dual port output data
#define W25X64_CMD_PAGEPROG		0x02		//page program 1page == 256Bytes  A23-A0 D7-D0 (next byte data)
#define W25X64_CMD_BERASE			0xD8		//block erase 1 block == 64KB	 A23-A0  block address
#define W25X64_CMD_SERASE			0x20		//sector erase 1 sector == 4KB	A23-A0 sector address
#define W25X64_CMD_CERASE			0xC7		//chip erase
#define W25X64_CMD_PWRDOWN		0xB9		//device power down
#define W25X64_CMD_RELPWRDOWN		0xAB		//release device from power down and read Device ID 3dummy ID7-ID0
#define W25X64_CMD_MANUFID		0x90		//read manufacturer ID  and Device ID	address 0x000000 M7-M0 ID7-ID0
#define W25X64_CMD_JEDECID		0x9F		//read JEDEC ID   (manufacturer ID)MID7-MID0	(memory type)ID15-ID8 	(capacity)ID7-ID0

/*W25X64 status register bit*/
#define SRP		7	//status register protect
#define TB		5	//top/bottom write protect
#define BP2		4
#define BP1		3
#define BP0		2	//block protect
#define WEL		1	//write enable latch		
#define BUSY	0	//erase or write in progress


typedef void(*P_SPIINT_CALLBACK)(void);
#define SPI_RX_SIZE	0x10
#define SPI_TX_SIZE	0x10


typedef enum{
	E_SPI_SLAVE_GET_CMD,
	E_SPI_SLAVE_READ,
	E_SPI_SLAVE_WRITE,
	
}E_SPI_SLAVE_STATUSE;

#define SPI_SLAVE_CMD_READ	0x05
#define SPI_SLAVE_CMD_WRITE	0x07

void SPI_MasterInit(E_SPI_CLK spi_rate, E_SPI_MODE eMode);
void SPI_SlaveInit(void);
void SPI_IntEnable(P_SPIINT_CALLBACK pSpintcallback);
void SPI_IntDisable(void);
void SPI_Int_MasterHandle(void);
void SPI_Int_SlaveHandle(void);

u8 SPI_RDWRByte(u8 cdata);
void W25X64_WriteCMD(u8 cmd);
void W25X64_Write_Address(u32 addr);
u8 W25X64_RDStatusReg(void);
void W25X64_WRStatusReg(u8 statusReg);
void W25X64_Read_ManuDevID(u8 *idbuf);
void W25X64_Read_JEDECID(u8 *idbuf);
void W25X64_ReadData(u32 addr, u16 datalength, u8 *databuf);
void W25X64_Fast_ReadData(u32 addr, u16 datalength, u8 *databuf);
void W25X64_Fast_ReadData_Daul(u32 addr, u16 datalength, u8 *databuf);
void W25X64_PageProg(u32 addr, u16 datalength, u8 *databuf);
void W25X64_ChipErase(void);
void W25X64_BlockErase(u32 addr);
void W25X64_SectorErase(u32 addr);
void W25X64_Demo(void);

#endif
/****************************************************************************************
*************************************End of File*******************************************/

