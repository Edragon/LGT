#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include "lgt8f88a.h"
#include "usbdrv.h"
#include "osccal.h"
#include <util/delay.h>
#include "oddebug.h"

#define USB_LED_ON	1
#define USB_LED_OFF	0
#define LED_PORT	PORTD
#define LED_DDR		DDRD
#define LED_PIN		3

USB_PUBLIC uchar usbFunctionSetup(uchar data [ 8 ])
{
	usbRequest_t *rq = (void *)data; // cast data to correct type 
	 
	switch(rq->bRequest) { // custom command is in the bRequest field 
	case USB_LED_ON: 
		LED_PORT |= _BV(LED_PIN);
		return 0; 
	case USB_LED_OFF: 
		LED_PORT &= ~_BV(LED_PIN);
		return 0; 
	} 
 
	return 0; // should not get here 

}
void lgt8f88es_init0 (void)
{
	// fix item2
	PCMSK0 |= 0x40;
	// fix item4
	TKCR = 0x0f;
}
void clk_init()
{
	/*PMCR = (1<<PMCE) | (1<<RCMEN);
	PMCR = (1<<PMCE) | (1<<OSCMEN) | (1<<RCMEN);
	_delay_ms(1);
	PMCR = (1<<PMCE) | (1<<OSCMEN) | (1<<RCMEN);
	PMCR = (1<<PMCE) | (1<<EXTEN) | (1<<OSCMEN) |(1<<RCMEN);
	CLKPR = 0x80;
	CLKPR = 0x00;//3.3V 32MHz*/
	PMCR = (1<<PMCE) | (1<<RCMEN);
	PMCR = (1<<PMCE) | (1<<RCMEN);
	CLKPR = 0x80;
	CLKPR = 0x01;//3.3V 16MHz
}
int main() 
{ 
    uchar i;
	uchar j;
	lgt8f88es_init0 ();
	clk_init();
	wdt_enable(WDTO_500MS);
	odDebugInit();
	DBG1(0x55,0,0);
	
	//OSCCAL = 0x3a;//校准代码的问题，在这里引发依次故意的复位
	
	LED_DDR |= _BV(LED_PIN);
	LED_PORT |= _BV(LED_PIN);
	
	usbInit(); 
    usbDeviceDisconnect(); 	// enforce re-enumeration 
    for(i = 0; i<100; i++)  // wait 500 ms 
    {
		wdt_reset();
        _delay_ms(1); 
    } 
    usbDeviceConnect(); 
    sei(); 		
	
    while(1) 
	{ 
        usbPoll(); 
        wdt_reset();
       /* PORTD = PORTD | _BV(PULSE) ;
        PORTD = PORTD & ~_BV(PULSE) ;
        PORTD = PORTD | _BV(PULSE) ;
        PORTD = PORTD & ~_BV(PULSE) ;
		PORTD = PORTD | _BV(PULSE) ;
        PORTD = PORTD & ~_BV(PULSE) ;
        PORTD = PORTD | _BV(PULSE) ;
        PORTD = PORTD & ~_BV(PULSE) ;*/
        //DBG1(0xaa,0,0)
    } 
 
    return 0; 
}


