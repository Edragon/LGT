/* Name: hidtool.c
用于LGT Bootloader
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>  
#include <math.h>

#include "hiddata.h"
#include "intelhex.h"

#include "../firmware/usbconfig.h"  /* for device VID, PID, vendor name and product name */
#include "../firmware/requests.h"  /* request类型 */
#include "../firmware/bootconfig.h"  /* bootloader设置 */
	char        buffer[133];    /* room for dummy report ID */
	char dataBuffer[65536 + 256];
	int         err;
	int 		len;
	int			mcusize;
/* ------------------------------------------------------------------------- */

static char *usbErrorMessage(int errCode)
{
static char buffer[80];

    switch(errCode){
        case USBOPEN_ERR_ACCESS:      return "Access to device denied";
        case USBOPEN_ERR_NOTFOUND:    return "The specified device was not found";
        case USBOPEN_ERR_IO:          return "Communication error with device";
        default:
            sprintf(buffer, "Unknown USB error %d", errCode);
            return buffer;
    }
    return NULL;    /* not reached */
}

static usbDevice_t  *openDevice(void)
{
usbDevice_t     *dev = NULL;
unsigned char   rawVid[2] = {USB_CFG_VENDOR_ID}, rawPid[2] = {USB_CFG_DEVICE_ID};
char            vendorName[] = {USB_CFG_VENDOR_NAME, 0}, productName[] = {USB_CFG_DEVICE_NAME, 0};
int             vid = rawVid[0] + 256 * rawVid[1];
int             pid = rawPid[0] + 256 * rawPid[1];
int             err;

    if((err = usbhidOpenDevice(&dev, vid, vendorName, pid, productName, 0)) != 0){
        fprintf(stderr, "error finding %s: %s\n", productName, usbErrorMessage(err));
        return NULL;
    }
    return dev;
}

/* ------------------------------------------------------------------------- */

static void hexdump(char *buffer, int len)
{
int     i;
FILE    *fp = stdout;

    for(i = 0; i < len; i++){
        if(i != 0){
            if(i % 16 == 0){
                fprintf(fp, "\n");
            }else{
                fprintf(fp, " ");
            }
        }
        fprintf(fp, "0x%02x", buffer[i] & 0xff);
    }
    if(i != 0)
        fprintf(fp, "\n");
}
/*
static int  hexread(char *buffer, char *string, int buflen)
{
char    *s;
int     pos = 0;

    while((s = strtok(string, ", ")) != NULL && pos < buflen){
        string = NULL;
        buffer[pos++] = (char)strtol(s, NULL, 0);
    }
    return pos;
}*/

/* ------------------------------------------------------------------------- */
void titleMsg()
{
	printf("bootHIDLGT,一个使用HID协议运行在LGT单片机上的引导程序\n");
}	
void bugMsg()
{
	printf( "\nBUG 报告/讨论地址：<http://rgwan.byethost10.com>\n");
	printf("已知BUG：无法使用Bin文件。将在下一版本修正！\n");
    printf( "万致远 @ KMStudio 2013 \n");
}
void helpMsg(char *myName)
{
	titleMsg();
    printf("用法: %s [选项]\n",myName);
    printf("选项：\n");
    printf("	-v,--version		显示版本号\n");
    printf("	-h,--help		显示帮助\n");
    printf("	-l,--leave		下载程序后离开引导程序\n");
    printf( "	-e,--erase		仅仅擦除芯片\n");
    printf( "	-i,--info		仅仅取得命令参数\n");
    printf( "	-f,--file <程序文件>	指定代码文件\n");

	bugMsg();
}
void verMsg()
{
	char version[]={BOOT_VERSION};
	titleMsg();
	printf("上位机版本	:%d.%d\n",version[1],version[0]);
	printf("构建时间	：%s\n",__TIME__);
	printf("构建日期	: %s\n",__DATE__);
	bugMsg();
}
//usbHIDGetReport(dev,reportID,buffer,len)
void Erase(usbDevice_t *dev)
{
	printf("擦除芯片\n");
	buffer[0]=CMD_ERASE;//擦除命令
	if((err = usbhidSetReport(dev, buffer, sizeof(buffer))) != 0) 
	{
		printf("擦除芯片失败！\n");  /* add a dummy report ID */
		exit(1);
	}
	usleep(800);//等待内部擦除完毕
	printf("擦除芯片成功！\n");
}
void Leave(usbDevice_t *dev)
{
	printf("离开bootloader.\n");
	buffer[0]=CMD_LEAVE;//离开
	usbhidSetReport(dev, buffer, sizeof(buffer));
}
char *Chip_Type(unsigned char code)
{
	if(code==0x01) return "LGT8F08A";
	return "I don't know";
}
int main(int argc, char **argv)
{//这里需要解析Hex/Bin文件。以及命令行解析
	usbDevice_t *dev;

	char    *filename = NULL;
	int longIndex = 0;  
	char * optString = "ivhlef:";  
	int opt=0;
	int k;
	unsigned char i;
	int startAddress,endAddress,b;
	char oe=0;//OE为仅仅擦除标志
	char lv=0;//lv为离开标志
	
	struct option longOpts[] =  
	{  
		{ "version", no_argument, NULL, 'v' },  
		{ "help", no_argument, NULL, 'h' },  
		{ "leave", no_argument, NULL, 'l' },  
		{ "erase", no_argument, NULL, 'e' },  
		{ "file", required_argument, NULL, 'f' },  
		{ "info", no_argument, NULL, 'i' },  
		{ NULL, no_argument, NULL, 0 }  
	};
	if(argc < 2){
		printf("%s: 没有命令参数\n\n",argv[0]);
        printf("请尝试使用 '%s --help' 来获得帮助选项\n",argv[0]);
        return -1;
    }
	while((opt=getopt_long(argc, argv, optString, longOpts, &longIndex)) != -1)  
	{  
		switch(opt)  
		{  
		  case 'v':  
			verMsg();
			return 0;
			break;  
		  case 'f':  
			filename=optarg; 
			break;  
		  case 'e':  
			oe=1;
			break;  
		  case 'l':
			lv=1;
			break;  
		  case 'h':
			helpMsg(argv[0]);
			return 0;
			break;       
		  case 'i':
			break;
		  default:  
			/* Invalid paramater*/   
			printf("请尝试使用 '%s --help' 来获得帮助选项\n",argv[0]);

			return -1;  
		}  
	}
	/*if(filename==0)
	{
		printf("没有输入文件名，仅仅取得MCU信息.\n");
	}*/

    if((dev = openDevice()) == NULL)
        exit(1);
        printf("打开HID设备成功.\n");
        
        len=SIGN_SIZE;
        if((err = usbhidGetReport(dev, CMD_READSIGN, buffer, &len)) != 0){
            fprintf(stderr, "error reading data: %s\n", usbErrorMessage(err));
        }else{
             //hexdump(buffer + 1, sizeof(buffer) - 1);
            printf("单片机型号		：%s \n",Chip_Type(buffer[10]));
            printf("单片机扇区大小		：%d B\n",(buffer[3]<<8)+buffer[2]);
            printf("单片机可用空间大小	：%d B\n",(buffer[5]<<8)+(buffer[6]<<16)+buffer[4]);
            printf("引导器版本：		：%d.%d\n",(unsigned char)buffer[9],(unsigned char)buffer[8]);
            
            mcusize=(buffer[5]<<8)+(buffer[6]<<16)+buffer[4];
        }
        if(oe==1)
        {
			Erase(dev);

			return 0;
		}
			if(filename!=0)
			{
				/*k=0x0000;
				for(k=0;k<mcusize;k+=128)
				{
					printf("写入测试数据,Address:%d\n",k);
					buffer[0]=CMD_DATA;
					for(i=3;i<131;i++)
					{
						buffer[i]=(i-3);
					}
					buffer[1]=k >> 8;//Addr H
					buffer[2]=k & 0xFF;//Addr L
					hexdump(buffer, sizeof(buffer));
					len=132;
					if((err = usbhidSetReport(dev, buffer, len)) != 0) 
					{
						fprintf(stderr, "error reading data: %s\n", usbErrorMessage(err));
						exit(0);
					}	
					usleep(8000);//写一包等8mS
					//sleep(1);
				}		
				//sleep(1);*/
				 memset(dataBuffer, -1, sizeof(dataBuffer));
				 startAddress=0;endAddress=0;
				if(parseIntelHex(filename, dataBuffer, &startAddress, &endAddress))
				return 1;
				
				printf("程序大小		：%d (0x%X)\n",(endAddress - startAddress),(endAddress - startAddress));
				if((endAddress - startAddress) > mcusize)
				{
					fprintf(stderr,"超出 %d B\n",(endAddress - startAddress) -mcusize);
					fprintf(stderr,"无法下载程序：MCU空间不足！\n");
					exit(0);
				}
				Erase(dev);
				sleep(1);
				usleep(30000);
				printf("下载 %d (0x%x) 字节 从 %d (0x%x) 地址开始\n", endAddress - startAddress, endAddress - startAddress, startAddress, startAddress);
				b=(endAddress / 128);
				if(((double)endAddress / 128) > b) b++;
				for(k=0;k<b;k++)
				{
					//printf("写入数据,Address:%d\n",k);
					buffer[0]=CMD_DATA;
					for(i=3;i<131;i++)
					{
						if(((i-3)+k*128) > endAddress)
						buffer[i]=0xff;
						else
						buffer[i]=dataBuffer[(i-3)+k*128];
						//buffer[i]=(i-3);
					}
					buffer[1]=(k*128) >> 8;//Addr H
					buffer[2]=(k*128) & 0xFF;//Addr L,忘了*128，巨坑！
					//hexdump(buffer, sizeof(buffer));
					printf("下载到 - %d %% \n",(k*100/(b-1)));
					len=133;
					if((err = usbhidSetReport(dev, buffer, len)) != 0) 
					{
						fprintf(stderr, "写入区块：%d 失败: %s\n",k*128, usbErrorMessage(err));
						exit(0);
					}	
					usleep(30000);//写一包等13mS内部写完。这里我偷懒就没有加校验码
				}					
				printf("\n下载完成！\n");
				//printf("endAddress :0x%x\n",endAddress);
			}
		/*	len=128;
        if((err = usbhidGetReport(dev, 10, buffer, &len)) != 0){
            fprintf(stderr, "error reading data: %s\n", usbErrorMessage(err));
        }else{
             hexdump(buffer + 1, 128);
        }*/

		if(lv==1)
		{
			Leave(dev);
		}

        /*
    }else if(strcasecmp(argv[1], "write") == 0){
        int i, pos;
        memset(buffer, 0, sizeof(buffer));
        for(pos = 1, i = 2; i < argc && pos < sizeof(buffer); i++){
            pos += hexread(buffer + pos, argv[i], sizeof(buffer) - pos);
        }
        if((err = usbhidSetReport(dev, buffer, sizeof(buffer))) != 0) fprintf(stderr, "error writing data: %s\n", usbErrorMessage(err)); */ /* add a dummy report ID */
            
    usbhidCloseDevice(dev);
    printf("关闭HID设备.\n");
    return 0;
}

/* ------------------------------------------------------------------------- */
