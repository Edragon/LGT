#ifndef INTEL_HEX_H
#define INTEL_HEX_H
int  parseIntelHex(char *hexfile, char buffer[65536 + 256], int *startAddr, int *endAddr);
#endif
