/***一些协议定义******/
#define LGT_CMD_EXIT 		0xAA
#define LGT_CMD_DATA		0x00
#define LGT_CMD_SET			0x01
#define LGT_CMD_ERASE		0xA5

#define SEL_EEPROM			0x00
#define SEL_FLASH			0x01
