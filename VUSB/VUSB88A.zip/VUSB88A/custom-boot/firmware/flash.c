#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>
#include "lgt8f88a.h"
#include "flash.h"

uchar eeprom_read_byte(unsigned int addr)
{
	// wait for completion of previous write
	while(EECR & (1 << EEPE));
	// address
	EEARH = (addr >> 8) & 0x3;
	EEARL = (addr) & 0xff;
	// start eeprom read by writting EERE
	EECR |= (1 << EERE);
	asm("nop");
	asm("nop");
	// return data from data register
	return EEDR;
}

void flash_flush_page(unsigned int wAddr, unsigned char wLen, unsigned char *pData,uchar mmsel)
{
	unsigned char  i;
	// clear global interrupt enable
	cli();
	for(i = 0; i < wLen; i++)
	{
		// wait for completion of previous write
		while(EECR & (1 << EEPE));
		wAddr = wAddr & 0xfffc;
		// address
		EEARH = (wAddr >> 8) & 0xff;
		EEARL = (wAddr) & 0xff;
		wAddr += 1;
		// data
		EEDR = *pData++;
		//
		EEARL = (wAddr) & 0xff;
		EEDR = *pData++;
		wAddr += 1;
		//
		EEARL = (wAddr) & 0xff;
		EEDR = *pData++;
		wAddr += 1;
		//
		EEARL = (wAddr) & 0xff;
		EEDR = *pData++;
		wAddr += 1;
		// Program Mode
		if(mmsel)
			EECR = 0xa0 | (1 << EERIE);//程序flash
		else
			EECR = 0x40 | (1 << EERIE);//EEPROM
		// write logical one to EEMWE
		// start eeprom write by setting EEWE

		asm volatile
		(
			"sbi 0x1f, %0\n\t"			//EECR |= (1 << EEMWE);
			"sbi 0x1f, %1\n\t"			//EECR |= (1 << EEWE);
			::"M"(EEMPE),"M"(EEPE)
		);

	}
	// wait for completion of This write
	while(EECR & (1 << EEPE));

	EECR = (EECR & (1 << EERIE));
	
	sei();
}
void flash_erase_page(unsigned int pAddr)
{
	// read status register
	// clear global interrupt enable
	cli();
	
	// wait for completion of previous write
	while(EECR & (1 << EEPE));
	// address
	EEARH = (pAddr >> 8) & 0xff;
	EEARL = (pAddr) & 0xff;
	// data
	//EEDRL = *wData & 0xff;
	//EEDRH = (*wData >> 8) & 0xff;
	// Program Mode
	EECR = EECR = 0x90;
	// write logical one to EEMWE
	// start eeprom write by setting EEWE

	asm volatile
	(
		"sbi 0x1f, %0\n\t"			//EECR |= (1 << EEMWE);
		"sbi 0x1f, %1\n\t"			//EECR |= (1 << EEWE);
		::"M"(EEMPE),"M"(EEPE)
	);
	// wait for completion of This write
	while(EECR & (1 << EEPE));

	EECR = 0x0;
		
	sei();
}
