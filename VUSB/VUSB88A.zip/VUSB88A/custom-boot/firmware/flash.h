#ifndef uchar
typedef unsigned char uchar;
#endif
#ifndef FLASH_H
#define FLASH_H
 uchar eeprom_read_byte(unsigned int addr);
 void flash_erase_page(unsigned int pAddr);
 void flash_flush_page(unsigned int wAddr, unsigned char wLen, unsigned char *pData,uchar mmsel);

#endif
