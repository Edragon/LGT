/*
 * LGT Loader
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include "lgt8f88a.h"
#include <util/delay.h>
#include <string.h>


#include "bootloaderconfig.h"
#include "usbdrv/usbdrv.c"
#include "flash.h"
#include "requests.h"
/* ------------------------------------------------------------------------ */



//变量定义
uchar cache[256];
uchar bytesRemaining;
unsigned int currentAddress;
uchar action;//动作
uchar cacheptr;
uchar verify;
uchar request_erase;
uchar request_write;
uchar *PGM = (uchar*)0x4000;
void (*jump_to_app)(void) = 0x0032;
/* ------------------------------------------------------------------------ */
uchar   usbFunctionSetup(uchar data[8])
{
usbRequest_t    *rq = (void *)data;
uchar           len = 0;
static uchar    replyBuffer[4];

    usbMsgPtr = replyBuffer;
    if(rq->bRequest == LGT_CMD_ERASE)
    {   
		len = 0;
	}
    return len;
}

uchar usbFunctionWrite(uchar *data, uchar len)
{

}
uchar usbFunctionRead(uchar *data, uchar len)
{
	
}
/* ------------------------------------------------------------------------ */

static void initForUsbConnectivity(void)
{
uchar   i = 0;

    usbInit();
    /* enforce USB re-enumerate: */
    usbDeviceDisconnect();  /* do this while interrupts are disabled */
    while(--i){         /* fake USB disconnect for > 250 ms */
       // wdt_reset();
        _delay_ms(1);
    }
    usbDeviceConnect();
    sei();
}
void clk_init()
{
	#ifndef INNER_RC
	PMCR = (1<<PMCE) | (1<<RCMEN);
	PMCR =  (1<<OSCMEN) | (1<<RCMEN);
	_delay_ms(1);
	PMCR = (1<<PMCE) | (1<<OSCMEN) | (1<<RCMEN);
	PMCR =  (1<<EXTEN) | (1<<OSCMEN) |(1<<RCMEN);
	CLKPR = 0x80;
	CLKPR = 0x00;//3.3V 32MHz
	#else
	/*PMCR = (1<<PMCE) | (1<<RCMEN);
	PMCR = (1<<PMCE) | (1<<RCMEN);
	CLKPR = 0x80;
	CLKPR = 0x01;*///3.3V 16MHz
	//OSCCAL = 0x3a;//for custom
	#endif
}
void boot_init()
{
	//disable WDT
	wdt_reset();
	cli();
	WDTCSR |= (1 << WDCE) | (1 << WDE);
	WDTCSR = 0x00;
	// move IV to Bootloader
	IVBASE = 6144 >> 9;// / 512;
	MCUCR = _BV(IVCE);//开启上拉
	MCUCR = _BV(IVSEL);//选择IV
}
int __attribute__((noreturn)) main(void)
{
    /* initialize  */
	boot_init();
	clk_init();
    //bootLoaderInit();
    odDebugInit();
    #if HAVE_CHIP_LOCK
		lock = 0;
    #endif
    DBG1(0x00, 0, 0);
    initForUsbConnectivity();
    //PORTD = PORTD | _BV(3);
    //DDRD  = DDRD  | _BV(3);
	while(1)
	{
		usbPoll();
	}
}

/* ------------------------------------------------------------------------ */
