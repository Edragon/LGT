/* Name: osccal.c
 * Author: Christian Starkjohann
 * Porting to LGT8F88A by 万致远 20130712
 * Creation Date: 2008-04-10
 * Tabsize: 4
 * Copyright: (c) 2008 by OBJECTIVE DEVELOPMENT Software GmbH
 * License: GNU GPL v2 (see License.txt), GNU GPL v3 or proprietary (CommercialLicense.txt)
 * This Revision: $Id$
 */

#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>
#include "oddebug.h"
#include <util/delay.h>

#ifndef uchar
#define uchar   unsigned char
#endif

/* ------------------------------------------------------------------------- */
/* ------------------------ Oscillator Calibration ------------------------- */
/* ------------------------------------------------------------------------- */

//usbMeasureFrameLength
//; returns time between two idle strobes in multiples of 7 CPU clocks
// t = 0A71 (万致远的测试)[1002]
// t = 0A56 (不行)
// t = 0A8B (不行)
//Tframe = Length * 6 * MachineT(0.0625uS)
//Length = Tframe / ( 6 * MachineT)
#ifdef INNER_RC

void    calibrateOscillator(void)
{
	int i,x;
	int caliValue = 1000 * (F_CPU/6e6) ;// A6A ~ A78可以接受(+-7)
	uchar       step = 32;//步长定在OSCCAL大小的一半左右
	uchar       trialValue = 0, optimumValue;
	uchar optimumDev;
	x = usbMeasureFrameLength();
	if( x <= (caliValue + 10) && x >= (caliValue - 10))
	{
		return;//防止多余工作
	}
	DBG1(0xfe,0,0);
    /* 二分法: */
    do
    {
        OSCCAL = trialValue + step;
        x = usbMeasureFrameLength();    /* 粗调 */
        if(x < caliValue)             /* 频率仍然太低 */
            trialValue += step;
        step >>= 1;
    }while(step > 0);
    
    /* 尽可能找到最接近的OSCCAL值 */
    /* 临近搜索算法 */
    optimumValue = trialValue;
    optimumDev = x; 
    /* 这比校准后差值的肯定不准 */
    for(OSCCAL = trialValue - 1; OSCCAL <= trialValue + 1; OSCCAL++)
    {
        x = usbMeasureFrameLength() - caliValue;
        if(x < 0)
            x = -x;
        if(x < optimumDev){
            optimumDev = x;
            optimumValue = OSCCAL;
        }
    }
    OSCCAL = optimumValue;
}
void	usbEventResetReady(void)
{
	//本函数在USB系统复位后调用
     //钩子函数
    //开启WDT
    //uchar past = OSCCAL;
    
    cli();
    calibrateOscillator();
    //wdt_reset();
    sei();
    //wdt_reset();
    //if(past == OSCCAL)
    //eeprom_write_byte(0, OSCCAL);   /* 把OSCCAL写入EEPROM */
}
#endif

