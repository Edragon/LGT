/* Name: main.c
 * Project: USBaspLoader
 * Author: Christian Starkjohann
 * Creation Date: 2007-12-08
 * Tabsize: 4
 * Copyright: (c) 2007 by OBJECTIVE DEVELOPMENT Software GmbH
 * License: GNU GPL v2 (see License.txt)
 * This Revision: $Id$
 * EEP 拿掉
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include "lgt8f88a.h"
#include <util/delay.h>
#include <string.h>

static void leaveBootloader() __attribute__((__noreturn__));

#include "bootloaderconfig.h"
#include "usbdrv/usbdrv.c"
#include "flash.h"
/* ------------------------------------------------------------------------ */

/* Request constants used by USBasp */
#define USBASP_FUNC_CONNECT         1
#define USBASP_FUNC_DISCONNECT      2
#define USBASP_FUNC_TRANSMIT        3
#define USBASP_FUNC_READFLASH       4
#define USBASP_FUNC_ENABLEPROG      5
#define USBASP_FUNC_WRITEFLASH      6
#define USBASP_FUNC_READEEPROM      7
#define USBASP_FUNC_WRITEEEPROM     8
#define USBASP_FUNC_SETLONGADDRESS  9
#define USBASP_FUNC_SETISPSCK		10

/* ------------------------------------------------------------------------ */

#ifndef ulong
#   define ulong    unsigned long
#endif
#ifndef uint
#   define uint     unsigned int
#endif

/* defaults if not in config file: */
#ifndef HAVE_EEPROM_PAGED_ACCESS
#   define HAVE_EEPROM_PAGED_ACCESS 0
#endif
#ifndef HAVE_EEPROM_BYTE_ACCESS
#   define HAVE_EEPROM_BYTE_ACCESS  0
#endif
#ifndef BOOTLOADER_CAN_EXIT
#   define  BOOTLOADER_CAN_EXIT     0
#endif

/* allow compatibility with avrusbboot's bootloaderconfig.h: */
#ifdef BOOTLOADER_INIT
#   define bootLoaderInit()         BOOTLOADER_INIT
#   define bootLoaderExit()
#endif
#ifdef BOOTLOADER_CONDITION
#   define bootLoaderCondition()    BOOTLOADER_CONDITION
#endif

/* device compatibility: */
#ifndef GICR    /* ATMega*8 don't have GICR, use MCUCR instead */
#   define GICR     MCUCR
#endif

/* ------------------------------------------------------------------------ */

#if (FLASHEND) > 0xffff /* we need long addressing */
#   define CURRENT_ADDRESS  currentAddress.l
#   define addr_t           ulong
#else
#   define CURRENT_ADDRESS  currentAddress.w[0]
#   define addr_t           uint
#endif

typedef union longConverter{
    addr_t  l;
    uint    w[sizeof(addr_t)/2];
    uchar   b[sizeof(addr_t)];
}longConverter_t;

static uchar            requestBootLoaderExit;
static longConverter_t  currentAddress; /* in bytes */
static uchar            bytesRemaining;
//static uchar            isLastPage;
#if HAVE_EEPROM_PAGED_ACCESS
static uchar            currentRequest;
#else
static const uchar      currentRequest = 0;
#endif

uchar *MAP_PGM = (uchar *)0x4000; // LGT8F88A将flash空间映射到内存从0x4000开始的区域

#if HAVE_CHIP_LOCK
uchar lock;
#endif
#if HAVE_CHIP_ERASE
uchar request_erase=0;
#endif
uchar request_write=0;
uchar cache[256];
uchar intr[4];
uchar cacheptr;
uchar blocksize;

static const uchar  signatureBytes[4] = {
#ifdef SIGNATURE_BYTES
    SIGNATURE_BYTES
#elif defined (__AVR_ATmega8__) || defined (__AVR_ATmega8HVA__)
    0x1e, 0x93, 0x07, 0
#elif defined (__AVR_ATmega48__) || defined (__AVR_ATmega48P__)
    0x1e, 0x92, 0x05, 0
#elif defined (__AVR_ATmega88__) || defined (__AVR_ATmega88P__)
    0x1e, 0x93, 0x0a, 0
#elif defined (__AVR_ATmega168__) || defined (__AVR_ATmega168P__)
    0x1e, 0x94, 0x06, 0
#elif defined (__AVR_ATmega328P__)
    0x1e, 0x95, 0x0f, 0
#else
#   error "Device signature is not known, please edit main.c!"
#endif
};

/* ------------------------------------------------------------------------ */

static void (*nullVector)(void) __attribute__((__noreturn__));

static void leaveBootloader()
{

}

/* ------------------------------------------------------------------------ */
uchar   usbFunctionSetup(uchar data[8])
{
usbRequest_t    *rq = (void *)data;
uchar           len = 0;
static uchar    replyBuffer[4];

    usbMsgPtr = replyBuffer;
    if(rq->bRequest == USBASP_FUNC_TRANSMIT){   /* emulate parts of ISP protocol */
        uchar rval = 0;
        usbWord_t address;
        address.bytes[1] = rq->wValue.bytes[1];
        address.bytes[0] = rq->wIndex.bytes[0];
        if(rq->wValue.bytes[0] == 0x30){        /* read signature */
            rval = rq->wIndex.bytes[0] & 3;
            rval = signatureBytes[rval];
#if HAVE_EEPROM_BYTE_ACCESS
        }else if(rq->wValue.bytes[0] == 0xa0){  /* read EEPROM byte */
            //rval = eeprom_read_byte((void *)address.word);
        }else if(rq->wValue.bytes[0] == 0xc0){  /* write EEPROM byte */
            //eeprom_write_byte((void *)address.word, rq->wIndex.bytes[1]);
#endif
#if HAVE_CHIP_ERASE
        }else if(rq->wValue.bytes[0] == 0xac && rq->wValue.bytes[1] == 0x80){  /* chip erase */
			request_erase = 20;
#endif
        }else{
            /* ignore all others, return default value == 0 */
        }
        replyBuffer[3] = rval;
        len = 4;
    }else if(rq->bRequest == USBASP_FUNC_ENABLEPROG || rq->bRequest == USBASP_FUNC_SETISPSCK){
        /* replyBuffer[0] = 0; is never touched and thus always 0 which means success */
        len = 1;
    }else if(rq->bRequest >= USBASP_FUNC_READFLASH && rq->bRequest <= USBASP_FUNC_SETLONGADDRESS){
        currentAddress.w[0] = rq->wValue.word;
        if(rq->bRequest == USBASP_FUNC_SETLONGADDRESS){
#if (FLASHEND) > 0xffff
            currentAddress.w[1] = rq->wIndex.word;
#endif
        }else{
            bytesRemaining = rq->wLength.bytes[0];
            blocksize = bytesRemaining;
            cacheptr = 0;
            /* if(rq->bRequest == USBASP_FUNC_WRITEFLASH) only evaluated during writeFlash anyway */
            //isLastPage = rq->wIndex.bytes[1] & 0x02;
#if HAVE_EEPROM_PAGED_ACCESS
            currentRequest = rq->bRequest;
#endif
            len = USB_NO_MSG; /* hand over to usbFunctionRead() / usbFunctionWrite() */
        }
#if BOOTLOADER_CAN_EXIT
    }else if(rq->bRequest == USBASP_FUNC_DISCONNECT){
        requestBootLoaderExit = 1;      /* allow proper shutdown/close of connection */
#endif
    }else{
        /* ignore: USBASP_FUNC_CONNECT */
    }
    return len;
}

uchar usbFunctionWrite(uchar *data, uchar len)
{
uchar   isLastWrite;
uchar i;
    DBG1(0x31, (void *)&currentAddress.l, 4);
    if(len > bytesRemaining)
        len = bytesRemaining;
        
    bytesRemaining -= len;
    isLastWrite = bytesRemaining == 0;
    if(currentRequest >= USBASP_FUNC_READEEPROM)
    {
       // eeprom_write_block(data, (void *)currentAddress.w[0], len);
       //cache
        //currentAddress.w[0] += len;
    }
    else
    {
        for(i = 0; i<len ;i++)
        {
			cache[cacheptr + i] = data[i];
		}
    }
    if(isLastWrite) request_write=4;
    cacheptr +=len;
    return isLastWrite;	
}
uchar usbFunctionRead(uchar *data, uchar len)
{
uchar   i;

    if(len > bytesRemaining)
        len = bytesRemaining;
    bytesRemaining -= len;
    for(i = 0; i < len; i++){
        if(currentRequest >= USBASP_FUNC_READEEPROM){
			/*#if HAVE_CHIP_LOCK
				if(lock == 1)
				{
					*data = 0xff;
				}
				else
				{
					*data = eeprom_read_byte(CURRENT_ADDRESS);
				}
			#else*/
				*data = eeprom_read_byte(CURRENT_ADDRESS);
			//#endif
				
        }
        else
        {
			/*#if HAVE_CHIP_LOCK
				if(lock == 1)
				{
					*data = 0xff;
				}
				else
				{			
					*data = MAP_PGM[CURRENT_ADDRESS];////pgm_read_byte((void *)CURRENT_ADDRESS);
				}
			#else*/
				*data = MAP_PGM[CURRENT_ADDRESS];
			//#endif
        }
        data++;
        CURRENT_ADDRESS++;
    }
    return len;	
}
/* ------------------------------------------------------------------------ */

static void initForUsbConnectivity(void)
{
uchar   i = 0;

    usbInit();
    /* enforce USB re-enumerate: */
    usbDeviceDisconnect();  /* do this while interrupts are disabled */
    while(--i){         /* fake USB disconnect for > 250 ms */
        wdt_reset();
        _delay_ms(1);
    }
    usbDeviceConnect();
    sei();
}
void clk_init()
{
	PMCR = (1<<PMCE) | (1<<RCMEN);
	PMCR =  (1<<OSCMEN) | (1<<RCMEN);
	_delay_ms(1);
	PMCR = (1<<PMCE) | (1<<OSCMEN) | (1<<RCMEN);
	PMCR =  (1<<EXTEN) | (1<<OSCMEN) |(1<<RCMEN);
	CLKPR = 0x80;
	CLKPR = 0x00;//3.3V 32MHz
	/*PMCR = (1<<PMCE) | (1<<RCMEN);
	PMCR = (1<<PMCE) | (1<<RCMEN);
	CLKPR = 0x80;
	CLKPR = 0x01;*///3.3V 16MHz
	//OSCCAL = 0x3a;//for custom
}
void boot_init()
{
	//disable WDT
	wdt_reset();
	cli();
	WDTCSR |= (1 << WDCE) | (1 << WDE);
	WDTCSR = 0x00;
	// move IV to Bootloader
	IVBASE = 6144 >> 9;// / 512;
	MCUCR = _BV(IVCE);//开启上拉
	MCUCR = _BV(IVSEL);//选择IV
}
int __attribute__((noreturn)) main(void)
{
    /* initialize  */
	boot_init();
	clk_init();
    //bootLoaderInit();
    odDebugInit();
    #if HAVE_CHIP_LOCK
		lock = 0;
    #endif
    DBG1(0x00, 0, 0);
    initForUsbConnectivity();
    //PORTD = PORTD | _BV(3);
    //DDRD  = DDRD  | _BV(3);
	while(1)
	{
		usbPoll();
		#if HAVE_CHIP_ERASE
			if(request_erase > 1)
			{
				request_erase --;
			}
			if(request_erase == 1)
			{//修复broken pipe
				addr_t addr;
				for(addr = 0; addr < FLASHEND + 1 - 2048; addr += 512) {
					/* wait and erase page */
					DBG1(0x33, 0, 0);
					flash_erase_page(addr);//擦除
				}
				request_erase = 0;
			}
			if(request_write > 1)
			{
				request_write --;
			}
			if(request_write == 1)
			{
				flash_flush_page(CURRENT_ADDRESS,blocksize,cache,1);//写入flash
				request_write = 0;
			}
        #endif
	}
}

/* ------------------------------------------------------------------------ */
